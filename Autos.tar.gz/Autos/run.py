#!flask/bin/python

from app import app
app.run(debug=False)
