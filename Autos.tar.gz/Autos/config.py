WTF_CSRF_ENABLE= True
SECRET_KEY = 'neteam_Autos'
